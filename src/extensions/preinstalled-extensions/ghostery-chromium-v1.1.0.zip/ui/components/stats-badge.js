import { html } from "../../npm/hybrids/src/template/index.js";
//#region src/ui/components/stats-badge.js
/**
* Ghostery Browser Extension
* https://www.ghostery.com/
*
* Copyright 2017-present Ghostery GmbH. All rights reserved.
*
* This Source Code Form is subject to the terms of the Mozilla Public
* License, v. 2.0. If a copy of the MPL was not distributed with this
* file, You can obtain one at http://mozilla.org/MPL/2.0
*/
var stats_badge_default = { render: () => html`
    <template layout="row center width::2 height:2 padding:0:0.25">
      <ui-text type="label-xs" color="secondary"><slot></slot></ui-text>
    </template>
  `.css`
    :host {
      box-sizing: border-box;
      border: 1px solid var(--border-primary);
      border-radius: 4px;
    }
  ` };
//#endregion
export { stats_badge_default as default };
